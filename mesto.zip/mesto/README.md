# Проект: Место

ДЕМО - https://jetmod.github.io/mesto

## 4,5,6 спринт

## Технологии

1. JavaScript
2. Позиционирование
3. HTML
4. Nested БЭМ
5. git
6. media
7. адаптивная верстка
8. grid layout
9. template
10. валидация форм
11. Закрытие попапа кликом на оверлей
12. Закрытие попапа нажатием на Esc

### Обзор

- Figma
- Картинки

**Figma**

- [Ссылка на макет в Figma](https://www.figma.com/file/2cn9N9jSkmxD84oJik7xL7/JavaScript.-Sprint-4?node-id=0%3A1)
- [Ссылка на макет в Figma](https://www.figma.com/file/bjyvbKKJN2naO0ucURl2Z0/JavaScript.-Sprint-5?type=design&node-id=0-1&mode=design)
- [Ссылка на макет в Figma](https://www.figma.com/file/kRVLKwYG3d1HGLvh7JFWRT/JavaScript.-Sprint-6?type=design&node-id=0-1&mode=design&t=aT0eoFc9fLNq1JCS-0)
